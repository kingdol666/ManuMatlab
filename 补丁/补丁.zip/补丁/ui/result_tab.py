from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QGroupBox, QHBoxLayout, QPushButton, QCheckBox
)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

def create_result_tab(main_window):
    """创建结果可视化选项卡"""
    result_widget = QWidget()
    main_layout = QHBoxLayout(result_widget)
    main_layout.setContentsMargins(24, 24, 24, 24)
    main_layout.setSpacing(24)

    # --- 左侧：控制面板 ---
    control_panel = QWidget()
    control_layout = QVBoxLayout(control_panel)
    control_layout.setSpacing(16)
    control_panel.setFixedWidth(280)

    # 结果控制组
    control_group = QGroupBox("结果控制")
    control_group_layout = QVBoxLayout(control_group)
    control_group_layout.setContentsMargins(16, 20, 16, 16)
    control_group_layout.setSpacing(12)
    
    main_window.load_results_button = QPushButton("加载结果")
    main_window.load_results_button.clicked.connect(main_window.visualization_manager.load_visualization_state)
    control_group_layout.addWidget(main_window.load_results_button)
    
    save_button = QPushButton("保存结果")
    save_button.clicked.connect(main_window.visualization_manager.save_visualization_state)
    control_group_layout.addWidget(save_button)
    
    control_layout.addWidget(control_group)

    # 可视化组
    visualize_group = QGroupBox("可视化")
    visualize_group_layout = QVBoxLayout(visualize_group)
    visualize_group_layout.setContentsMargins(16, 20, 16, 16)
    visualize_group_layout.setSpacing(12)

    display_step_button = QPushButton("显示所有步骤结果")
    display_step_button.clicked.connect(main_window.visualization_manager.visualize_step_results)
    visualize_group_layout.addWidget(display_step_button)

    display_combined_contour_button = QPushButton("显示整体温度云图")
    display_combined_contour_button.clicked.connect(main_window.visualization_manager.visualize_combined_contour)
    visualize_group_layout.addWidget(display_combined_contour_button)

    display_temperature_profile_button = QPushButton("显示最终温度分布")
    display_temperature_profile_button.clicked.connect(main_window.visualization_manager.plot_temperature_profile)
    visualize_group_layout.addWidget(display_temperature_profile_button)
    
    display_step_params_button = QPushButton("显示步骤参数")
    display_step_params_button.clicked.connect(main_window.visualization_manager.display_all_step_parameters)
    visualize_group_layout.addWidget(display_step_params_button)

    main_window.show_curves_button = QPushButton("显示温度变化曲线")
    main_window.show_curves_button.clicked.connect(main_window.visualization_manager.show_temperature_curves)
    
    main_window.show_model_ids_checkbox = QCheckBox("显示模型ID")
    main_window.show_model_ids_checkbox.setChecked(True)
    
    curves_layout = QHBoxLayout()
    curves_layout.addWidget(main_window.show_curves_button)
    curves_layout.addStretch()
    visualize_group_layout.addLayout(curves_layout)
    visualize_group_layout.addWidget(main_window.show_model_ids_checkbox)

    save_plots_button = QPushButton("保存所有图片")
    save_plots_button.clicked.connect(main_window.visualization_manager.save_all_plots)
    visualize_group_layout.addWidget(save_plots_button)
    
    # 添加导出CSV按钮
    main_window.export_csv_button = QPushButton("导出所有结果为CSV")
    main_window.export_csv_button.clicked.connect(main_window.export_results_to_csv)
    visualize_group_layout.addWidget(main_window.export_csv_button)
    
    # 添加导出温度云图数据按钮
    main_window.export_contour_csv_button = QPushButton("导出温度云图数据为CSV")
    main_window.export_contour_csv_button.clicked.connect(main_window.visualization_manager.export_contour_data_to_csv)
    visualize_group_layout.addWidget(main_window.export_contour_csv_button)
    
    control_layout.addWidget(visualize_group)
    control_layout.addStretch()

    # --- 右侧：图表显示区域 ---
    chart_panel = QWidget()
    chart_layout = QVBoxLayout(chart_panel)
    chart_layout.setContentsMargins(0, 0, 0, 0)
    chart_layout.setSpacing(0)
    
    main_window.figure = Figure(figsize=(8, 6), dpi=100)
    main_window.figure.patch.set_alpha(0)
    main_window.canvas = FigureCanvas(main_window.figure)
    main_window.canvas.setObjectName("canvas")
    chart_layout.addWidget(main_window.canvas)

    main_layout.addWidget(control_panel)
    main_layout.addWidget(chart_panel, 1)

    return result_widget
